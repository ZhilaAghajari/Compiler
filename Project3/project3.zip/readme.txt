Zhila Aghajari
Zha6@pitt.edu

Project 3:

How to run the program : 

First make and then kindly follow the example below:

./runsemantic test/src3

Where you can try it on any of the test cases instead of src3

Also, I test it on elements machine 

What cases I considered : 